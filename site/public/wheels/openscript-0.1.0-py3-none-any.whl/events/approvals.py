from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import asdict, dataclass, field, replace
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any, Protocol

import structlog

logger = structlog.get_logger(__name__)

DEFAULT_TTL_SECONDS = 3600  # approvals expire back to blocked after 1h


class ApprovalStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"


def _typed(value: Any) -> Any:
    """*value* as plain JSON in which every piece says what type it was.

    Exact types, not isinstance: an IntEnum member is not the int it compares
    equal to, and should not be approved as if it were. A list and a tuple are
    deliberately the same thing here; nothing can be done with one that cannot
    be done with the other.
    """
    kind = type(value)
    if value is None:
        return ["none"]
    if kind is bool:
        return ["bool", value]
    if kind is int:
        return ["int", str(value)]
    if kind is float:
        return ["float", repr(value)]
    if kind is str:
        return ["str", value]
    if kind in (bytes, bytearray):
        return ["bytes", bytes(value).hex()]
    if kind in (list, tuple):
        return ["list", [_typed(item) for item in value]]
    if kind in (set, frozenset):
        return ["set", sorted((_typed(item) for item in value), key=_order)]
    if kind is dict:
        pairs = ([_typed(key), _typed(item)] for key, item in value.items())
        return ["dict", sorted(pairs, key=_order)]
    # Anything else is named by its type as well as its text, so a Decimal, a
    # UUID or a date cannot stand in for the string that spells it.
    return ["object", f"{kind.__module__}.{kind.__qualname__}", str(value)]


def _order(encoded: Any) -> str:
    return json.dumps(encoded)


def action_hash(action: str, input_data: dict[str, Any]) -> str:
    """Canonical fingerprint of (action, input) for approval binding.

    An approval is redeemable only against the exact action it was requested
    for — a matching hash proves the retried call carries the same action
    name and input/args, so a granted approval can't be replayed against a
    different tool call.

    "The same" means the same values of the same types. This used to be
    json.dumps(default=str), and str() forgets what it was given: Decimal("10")
    and the text "10" fingerprinted alike, as did {1: x} and {"1": x}. An
    approval for one was an approval for the other.
    """
    canonical = json.dumps(["action", action, _typed(input_data)], separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


def _new_expiry(ttl_seconds: int = DEFAULT_TTL_SECONDS) -> datetime:
    return datetime.now(UTC) + timedelta(seconds=ttl_seconds)


@dataclass
class ApprovalRecord:
    session_id: str
    agent_id: str
    action: str
    reason: str
    action_hash: str
    approval_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    expires_at: datetime = field(default_factory=_new_expiry)
    decided_by: str = ""

    @property
    def expired(self) -> bool:
        return datetime.now(UTC) >= self.expires_at

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        data["created_at"] = self.created_at.isoformat()
        data["expires_at"] = self.expires_at.isoformat()
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ApprovalRecord:
        return cls(
            session_id=data["session_id"],
            agent_id=data["agent_id"],
            action=data["action"],
            reason=data["reason"],
            action_hash=data["action_hash"],
            approval_id=data["approval_id"],
            status=ApprovalStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            expires_at=datetime.fromisoformat(data["expires_at"]),
            decided_by=data.get("decided_by", ""),
        )


class ApprovalStore(Protocol):
    """Storage for pending/decided approval records.

    Expired records behave as denied everywhere: they drop out of
    list_pending, can no longer be decided, and never redeem.
    """

    async def create(self, record: ApprovalRecord) -> None: ...

    async def get(self, approval_id: str) -> ApprovalRecord | None: ...

    async def list_pending(self) -> list[ApprovalRecord]: ...

    async def decide(
        self, approval_id: str, approved: bool, decided_by: str = ""
    ) -> ApprovalRecord | None:
        """Resolve a pending record. Returns the updated record, or None when
        the id is unknown. Raises ValueError when the record is no longer
        pending (already decided or expired)."""
        ...

    async def consume(self, approval_id: str, expected_hash: str) -> bool:
        """Single-use redemption: True iff the record exists, is approved,
        is not expired, and its action_hash matches — the record is deleted
        so it can never redeem twice."""
        ...


class InMemoryApprovalStore:
    """Dict-backed store for SINGLE-PROCESS use and tests only.

    SecureAgent runs in the caller's process while /v1/approvals runs in the
    server — an in-memory store is never visible to both. Use
    RedisApprovalStore whenever approvals are decided over the HTTP API.
    """

    def __init__(self) -> None:
        self._records: dict[str, ApprovalRecord] = {}

    async def create(self, record: ApprovalRecord) -> None:
        self._records[record.approval_id] = replace(record)

    async def get(self, approval_id: str) -> ApprovalRecord | None:
        record = self._records.get(approval_id)
        return replace(record) if record is not None else None

    async def list_pending(self) -> list[ApprovalRecord]:
        self._purge_expired()
        return [replace(r) for r in self._records.values() if r.status == ApprovalStatus.PENDING]

    async def decide(
        self, approval_id: str, approved: bool, decided_by: str = ""
    ) -> ApprovalRecord | None:
        record = self._records.get(approval_id)
        if record is None:
            return None
        if record.status != ApprovalStatus.PENDING or record.expired:
            raise ValueError(f"approval '{approval_id}' is not pending")
        record.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.DENIED
        record.decided_by = decided_by
        return replace(record)

    async def consume(self, approval_id: str, expected_hash: str) -> bool:
        record = self._records.get(approval_id)
        if (
            record is None
            or record.status != ApprovalStatus.APPROVED
            or record.expired
            or record.action_hash != expected_hash
        ):
            return False
        del self._records[approval_id]
        return True

    def _purge_expired(self) -> None:
        expired = [aid for aid, r in self._records.items() if r.expired]
        for aid in expired:
            del self._records[aid]


class RedisApprovalStore:
    """Redis-backed store — required whenever SecureAgent and the server run
    in separate processes (i.e. any real deployment of the approvals API).

    Records live at {prefix}:{approval_id} as JSON with a Redis TTL matching
    expires_at; pending ids are tracked in the {prefix}:pending set. Single-use
    redemption relies on DELETE's atomicity: only the caller whose DELETE
    returns 1 wins a concurrent redeem race. A decision is made under WATCH,
    so of two people deciding the same request at once, one is told it was
    already decided.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379/0",
        *,
        key_prefix: str = "openscript:approval",
    ) -> None:
        import redis.asyncio as aioredis

        self._redis = aioredis.from_url(url, decode_responses=True)
        self._prefix = key_prefix
        self._pending_key = f"{key_prefix}:pending"

    def _key(self, approval_id: str) -> str:
        return f"{self._prefix}:{approval_id}"

    @staticmethod
    def _ttl_seconds(record: ApprovalRecord) -> int:
        return max(1, int((record.expires_at - datetime.now(UTC)).total_seconds()))

    async def create(self, record: ApprovalRecord) -> None:
        await self._redis.set(
            self._key(record.approval_id),
            json.dumps(record.to_dict()),
            ex=self._ttl_seconds(record),
        )
        await self._redis.sadd(self._pending_key, record.approval_id)

    async def get(self, approval_id: str) -> ApprovalRecord | None:
        raw = await self._redis.get(self._key(approval_id))
        return ApprovalRecord.from_dict(json.loads(raw)) if raw else None

    async def list_pending(self) -> list[ApprovalRecord]:
        pending: list[ApprovalRecord] = []
        for approval_id in await self._redis.smembers(self._pending_key):
            record = await self.get(str(approval_id))
            if record is None or record.status != ApprovalStatus.PENDING:
                # expired (key TTL fired) or already decided — clean the set
                await self._redis.srem(self._pending_key, approval_id)
                continue
            pending.append(record)
        return pending

    async def decide(
        self, approval_id: str, approved: bool, decided_by: str = ""
    ) -> ApprovalRecord | None:
        from redis.exceptions import WatchError

        key = self._key(approval_id)
        # Read, check and write as one step. Without the WATCH, two people
        # deciding at the same moment both read "pending", both write, and both
        # are told it worked — an approval and a denial of the same request,
        # with whichever landed second quietly winning.
        # Typed Any: redis-py leaves multi() unannotated, and whether that is
        # an error depends on whether its types are installed where mypy runs.
        transaction: Any = self._redis.pipeline(transaction=True)
        async with transaction as pipe:
            while True:
                try:
                    await pipe.watch(key)
                    raw = await pipe.get(key)
                    record = ApprovalRecord.from_dict(json.loads(raw)) if raw else None
                    if record is None:
                        return None
                    if record.status != ApprovalStatus.PENDING or record.expired:
                        raise ValueError(f"approval '{approval_id}' is not pending")
                    record.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.DENIED
                    record.decided_by = decided_by
                    pipe.multi()
                    pipe.set(key, json.dumps(record.to_dict()), ex=self._ttl_seconds(record))
                    pipe.srem(self._pending_key, approval_id)
                    await pipe.execute()
                    return record
                except WatchError:
                    # Someone else wrote the record first. Read it again: it is
                    # no longer pending, and the check above says so.
                    continue

    async def consume(self, approval_id: str, expected_hash: str) -> bool:
        record = await self.get(approval_id)
        if (
            record is None
            or record.status != ApprovalStatus.APPROVED
            or record.expired
            or record.action_hash != expected_hash
        ):
            return False
        # DELETE returning 1 is the atomic single-use gate under concurrency
        return await self._redis.delete(self._key(approval_id)) == 1
